# Rock Paper Scissor Game
A simple game with simple UI and single player game. This is a javascript game.

## What will I get by playing it?
* Enjoyment
* Time Passing
* Coding Logic

## How to play
The game is very simple to play. Select a hand between this three hands and tap, which you want that is your own choice. Wait until it's finished then play again.

## How to run
### Option 1: Download
1. Click on the green button (top-right) 
2. Download the ZIP file
3. Extract the ZIP file in a folder 
4. Run the game

### Option 2: Clone
Follow the command and copy paste on your bash. 
``` 
git clone 
```